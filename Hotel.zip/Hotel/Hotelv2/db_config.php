<?php


$bdd = new PDO('mysql:host=localhost;dbname=hotel', 'root', '');


?>
