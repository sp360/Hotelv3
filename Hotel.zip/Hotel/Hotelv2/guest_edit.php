<?php

include 'nav.php';
require('conexion.php');

 ?>
 <body>
   <div class="container">
     <div class="row">
       <div class="col">
         <h2>Lista de Clientes</h2>

       </div>
       <div class="col-2">
         <button type="button" class="btn btn-danger"><i class="fas fa-edit"></i> Cerrar</button>

       </div>
     </div>
     <div class="row">
       <input type="text" class="form-control" id="myInput" onkeyup="myFunction()"  placeholder="Busqueda...">


     </div>
     <div class="row ">
       <div class="col shadow p-3 mb-5 bg-white rounded">
<table id="myTable" class="table table-striped table-borderless table-sm">
  <thead>
    <tr>
      <th scope="col">Nombre</th>
      <th scope="col">Direccion</th>
      <th scope="col">Genero</th>
      <th scope="col">Tipo de identificacion</th>
      <th scope="col"># identificacion</th>
      <th scope="col">Telefono</th>
      <th scope="col">Accion</th>


    </tr>
  </thead>
  <tbody>
    <?php
    $sql = "SELECT *  FROM guest";
    $result = mysqli_query($mysqli, $sql);

    if (mysqli_num_rows($result) > 0) {
      // output data of each row
      while($row = mysqli_fetch_assoc($result)) {
        echo '

        <tr>

          <td><input type="text" required class="form-control" id="nombre" name="nombre" value="'.$row['nombre'].'"></td>
          <td><input type="text" required class="form-control" id="address" name="address" value="'.$row['address'].'"></td>
          <td><input type="text" required class="form-control" id="genero" name="genero" value="'.$row['genero'].'"></td>
          <td><input type="text" required class="form-control" id="tipoidentificacion" name="tipoidentificacion" value="'.$row['tipoidentificacion'].'"></td>
          <td><input type="text" required class="form-control" id="nidentificacion" name="nidentificacion" value="'.$row['nidentificacion'].'"></td>
          <td><input type="text" required class="form-control" id="tel" name="tel" value="'.$row['tel'].'"></td>


        </tr>


        ';
          }
        }

     ?>
    </tbody>
  </table>
  <script>
function myFunction() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>
       </div>
     </div>
   </div>
 </body>
 </html>

 ?>
